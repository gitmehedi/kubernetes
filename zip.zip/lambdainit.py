"""Special initializations for Lambda."""

import sys

# add packaged dependencies to search path
sys.path.append('lib')
